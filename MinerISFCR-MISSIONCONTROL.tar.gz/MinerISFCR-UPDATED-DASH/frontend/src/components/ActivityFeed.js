import React from 'react';
import { coinColor } from '../utils/format';

const EVENT_META = {
  share_accepted:    { icon: '✓', color: '#00e676' },
  share_rejected:     { icon: '✕', color: '#ff8a65' },
  payout_received:   { icon: '$', color: '#ffca28' },
  block_found:       { icon: '★', color: '#ffca28' },
  pool_connected:    { icon: '●', color: '#00e676' },
  pool_disconnected: { icon: '●', color: '#ff1744' },
  miner_started:     { icon: '▶', color: '#2196f3' },
  miner_stopped:     { icon: '■', color: '#5a6478' },
};

function timeAgo(ts) {
  if (!ts) return '';
  const seconds = Math.max(0, Math.floor(Date.now() / 1000 - ts));
  if (seconds < 5) return 'just now';
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export default function ActivityFeed({ events, maxHeight = 360, emptyMessage = 'No activity yet — once mining starts, every accepted share, payout and connection event shows up here live.' }) {
  if (!events || events.length === 0) {
    return <div style={{ color: '#5a6478', fontSize: 13, padding: '8px 0' }}>{emptyMessage}</div>;
  }

  return (
    <div style={{ maxHeight, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 2 }}>
      {events.map((e, i) => {
        const meta = EVENT_META[e.event_type] || { icon: '•', color: '#8b95a8' };
        const color = e.coin ? coinColor(e.coin) : meta.color;
        return (
          <div key={e.id ?? `${e.ts}-${i}`} style={{
            display: 'flex', alignItems: 'flex-start', gap: 10, padding: '7px 4px',
            borderBottom: '1px solid #14181f', fontSize: 13,
            animation: i === 0 ? 'feedRowIn 0.4s ease' : 'none',
          }}>
            <span style={{
              width: 22, height: 22, borderRadius: 6, flexShrink: 0,
              background: `${meta.color}1f`, color: meta.color, fontWeight: 700,
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11,
            }}>{meta.icon}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: '#e8eaf0' }}>
                {e.coin && <span style={{ color, fontWeight: 700, marginRight: 6 }}>{e.coin}</span>}
                {e.message}
              </div>
            </div>
            <span style={{ color: '#5a6478', fontSize: 11, whiteSpace: 'nowrap', fontFamily: 'JetBrains Mono, monospace' }}>
              {timeAgo(e.ts)}
            </span>
          </div>
        );
      })}
      <style>{`
        @keyframes feedRowIn {
          0% { opacity: 0; transform: translateY(-6px); }
          100% { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
