import React, { useEffect, useState, useRef } from 'react';
import { useMiningData, API_BASE } from '../context/MiningDataContext';
import { Card, ErrorBanner, EmptyState, KpiCard, Badge } from '../components/UIPrimitives';
import { coinColor, fmt_datetime, fmt_hash, fmt_coin } from '../utils/format';

function toDate(value) {
  if (value === null || value === undefined) return null;
  // Pool APIs (2Miners/HeroMiners) use unix seconds; Blockscout returns ISO strings.
  return typeof value === 'number' ? new Date(value * 1000) : new Date(value);
}

const Metric = ({ label, value, color }) => (
  <div style={{ background: '#0d1015', border: '1px solid #1e2530', borderRadius: '8px', padding: '14px 16px', minWidth: '150px' }}>
    <div style={{ fontSize: '10px', color: '#5a6478', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '6px' }}>{label}</div>
    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '18px', fontWeight: 700, color: color || '#e8eaf0' }}>{value}</div>
  </div>
);

export default function BlockDiscovery() {
  const { stats, errors } = useMiningData();
  const [enrichment, setEnrichment] = useState({});
  const requested = useRef(new Set());

  const coin = stats && stats.coin;
  const pool = (stats && stats.pool) || {};
  const network = (stats && stats.network) || {};
  const bd = (stats && stats.block_discovery) || {};
  const blocksMined = pool.blocks_mined || [];
  const color = coinColor(coin);
  const hasShareData = bd.network_share_pct !== null && bd.network_share_pct !== undefined;
  const supportsEnrichment = coin === 'ETC';
  const nonOrphanCount = blocksMined.filter((b) => !b.orphan).length;

  // Lazily enrich each visible ETC block from Blockscout, once per height, ever.
  useEffect(() => {
    if (!supportsEnrichment) return;
    blocksMined.slice(0, 15).forEach((b) => {
      if (!b.height || requested.current.has(b.height)) return;
      requested.current.add(b.height);
      fetch(`${API_BASE}/blocks/enrich?coin=ETC&height=${b.height}`)
        .then((r) => r.json())
        .then((data) => {
          if (data && data.available) {
            setEnrichment((prev) => ({ ...prev, [b.height]: data }));
          }
        })
        .catch(() => {});
    });
  }, [blocksMined, supportsEnrichment]);

  if (!stats) return <div style={{ padding: 40, color: '#5a6478' }}>Connecting…</div>;

  return (
    <div style={{ maxWidth: '1300px', margin: '0 auto', padding: '32px 32px 60px' }}>
      <h1 style={{ fontSize: '22px', fontWeight: 800, margin: '0 0 8px' }}>Block Discovery</h1>
      <div style={{ fontSize: '13px', color: '#5a6478', marginBottom: '24px' }}>
        Current network height, plus every block {pool.pool_name || 'the pool'} has credited to this wallet —
        pulled straight from {pool.pool_name || "the pool's"} own API, no local guesswork.
      </div>
      <ErrorBanner errors={errors} />

      <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', marginBottom: '16px' }}>
        <KpiCard label="Current Block" icon="⛓" value={network.block_height != null ? network.block_height.toLocaleString() : '—'} sub={`${coin} network`} color={color} />
        <KpiCard label="Blocks Credited to You" icon="★" value={nonOrphanCount} sub="all-time, this wallet" color="#00e676" />
        <KpiCard label="Most Recent" icon="↑" value={blocksMined[0] ? blocksMined[0].height.toLocaleString() : '—'} sub={blocksMined[0] ? fmt_datetime(toDate(blocksMined[0].timestamp)) : 'none yet'} color="#5a6478" />
      </div>

      <Card title={`Block Discovery Analytics — ${coin}`}>
        {!hasShareData ? (
          <div style={{ fontSize: '13px', color: '#8b95a8' }}>
            {coin === 'ALPH'
              ? "Alephium doesn't publish a simple public network-hashrate figure, so the odds below can't be computed for ALPH specifically — switch to ETC, RVN, ERG or XMR to see this section live."
              : 'Waiting on network hashrate data to compute this.'}
          </div>
        ) : (
          <>
            <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', marginBottom: '14px' }}>
              <Metric label="Your Hashrate" value={fmt_hash((stats.xmrig || {}).hashrate_1m)} />
              <Metric label="Network Hashrate" value={fmt_hash(network.network_hashrate)} />
              <Metric label="Network Share" value={`${bd.network_share_pct < 0.001 ? bd.network_share_pct.toExponential(2) : bd.network_share_pct.toFixed(4)}%`} color={color} />
              <Metric label="Odds per Block" value={`1 in ${Math.round(100 / bd.probability_per_block_pct).toLocaleString()}`} />
            </div>
            <div style={{ fontSize: '13px', color: '#8b95a8', lineHeight: 1.6 }}>
              At this hashrate, solo mining would expect to find a block roughly every{' '}
              <span style={{ color, fontWeight: 700 }}>{bd.expected_solo_block_time_human || '—'}</span>.
              Mining through the pool instead pays out your fair share continuously (smoothed by the
              pool's combined luck) rather than as one rare lump sum — same long-run rate, far less
              lumpy, which is the whole point of pooling.
            </div>
          </>
        )}
      </Card>

      <div style={{ marginTop: '16px' }}>
        <Card title="Your Chain">
          <ChainStrip blocks={blocksMined} color={color} />
        </Card>
      </div>

      <div style={{ marginTop: '16px' }}>
        <Card title={`Blocks Mined — ${coin} (live from ${pool.pool_name || 'pool'} API)`}>
          {!pool.reachable && (
            <div style={{ marginBottom: 12 }}>
              <Badge color="#ff8a65" bg="#2a1410">{pool.error || 'Pool unreachable'}</Badge>
            </div>
          )}
          {blocksMined.length === 0 ? (
            <EmptyState message="No blocks credited to this wallet yet. This list comes straight from the pool's own per-wallet record, so it fills in automatically the moment the pool credits your share of a block." />
          ) : (
            <table style={{ width: '100%', fontSize: 13, borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', color: '#5a6478', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  <th style={{ padding: '6px 0' }}>Height</th>
                  <th>Reward</th>
                  <th>Share</th>
                  <th>When</th>
                  <th>Status</th>
                  {supportsEnrichment && <th>On-Chain (Blockscout)</th>}
                </tr>
              </thead>
              <tbody>
                {blocksMined.slice(0, 15).map((b) => {
                  const detail = enrichment[b.height];
                  return (
                    <tr key={b.height} style={{ borderTop: '1px solid #181d25', opacity: b.orphan ? 0.5 : 1 }}>
                      <td style={{ padding: '8px 0', color, fontFamily: 'JetBrains Mono, monospace' }}>{b.height != null ? b.height.toLocaleString() : '—'}</td>
                      <td style={{ fontFamily: 'JetBrains Mono, monospace' }}>{b.orphan ? '—' : fmt_coin(b.reward, 6)}</td>
                      <td style={{ color: '#8b95a8' }}>{b.percent != null ? `${(b.percent * 100).toFixed(2)}%` : '—'}</td>
                      <td style={{ color: '#5a6478' }}>{fmt_datetime(toDate(b.timestamp))}</td>
                      <td>{b.orphan ? <Badge color="#ff8a65" bg="#2a1410">Orphan</Badge> : <Badge color="#00e676" bg="#0d2818">Matured</Badge>}</td>
                      {supportsEnrichment && (
                        <td style={{ color: '#5a6478', fontSize: 12 }}>
                          {detail ? (
                            <a href={detail.explorer_url} target="_blank" rel="noreferrer" style={{ color }}>
                              {detail.tx_count ?? 0} tx · {detail.hash ? `${detail.hash.slice(0, 8)}…` : ''}
                            </a>
                          ) : 'loading…'}
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </Card>
      </div>
    </div>
  );
}

function ChainStrip({ blocks, color }) {
  // Show the last 12 blocks (or placeholders) as a connected chain visualization
  const display = blocks.slice(0, 12).reverse();
  const placeholders = Math.max(0, 6 - display.length);

  return (
    <div style={{ display: 'flex', alignItems: 'center', overflowX: 'auto', padding: '10px 0' }}>
      {Array.from({ length: placeholders }).map((_, i) => (
        <React.Fragment key={`ph-${i}`}>
          <div style={chainBlockStyle('#1a2128', '#2a3340')}>·</div>
          {i < placeholders - 1 && <Link />}
        </React.Fragment>
      ))}
      {display.map((b, i) => (
        <React.Fragment key={b.height}>
          {(placeholders > 0 || i > 0) && <Link />}
          <div style={chainBlockStyle(b.orphan ? '#2a182222' : `${color}22`, b.orphan ? '#ff8a65' : color)} title={`#${b.height}${b.orphan ? ' (orphan)' : ''}`}>
            {b.orphan ? '×' : '★'}
          </div>
        </React.Fragment>
      ))}
      {display.length === 0 && placeholders === 0 && (
        <div style={{ color: '#5a6478', fontSize: 13 }}>No chain data yet.</div>
      )}
    </div>
  );
}

const Link = () => <div style={{ width: '20px', height: '2px', background: '#2a3340', flexShrink: 0 }} />;

const chainBlockStyle = (bg, border) => ({
  width: '44px', height: '44px', borderRadius: '8px', flexShrink: 0,
  background: bg, border: `1.5px solid ${border}`,
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  fontSize: '14px', color: border, fontWeight: 700,
});
