import React, { useState } from 'react';
import { useMiningData } from '../context/MiningDataContext';
import { Card } from '../components/UIPrimitives';
import { coinColor, fmt_coin } from '../utils/format';

// QR code rendered as a pure SVG — no external library required,
// uses qrcode.react which is added to package.json.
let QRCode;
try {
  // Graceful degradation: if qrcode.react isn't installed yet (e.g. during
  // a fresh clone before npm install has run), fall back to a text display
  // of the address rather than throwing at module load time.
  QRCode = require('qrcode.react').QRCodeSVG;
} catch (_) {
  QRCode = null;
}

function copyToClipboard(text, setCopied) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  } else {
    // Fallback for older browsers / non-HTTPS contexts
    const el = document.createElement('textarea');
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }
}

function WalletCard({ coin, wallet, pool, color }) {
  const [copied, setCopied] = useState(false);
  const [showFull, setShowFull] = useState(false);
  const payouts = pool.payout_history || [];
  const shortAddr = wallet ? `${wallet.slice(0, 12)}…${wallet.slice(-8)}` : '—';

  return (
    <Card title={`${coin} Wallet`} accent={color}>
      <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        {/* QR code */}
        {QRCode && wallet ? (
          <div style={{
            background: '#fff', padding: 10, borderRadius: 8, flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <QRCode value={wallet} size={110} level="M" />
          </div>
        ) : (
          <div style={{
            width: 110, height: 110, background: '#1a2128', borderRadius: 8, flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 11, color: '#5a6478', textAlign: 'center', padding: 8,
          }}>
            {wallet ? 'Run npm install to show QR' : 'No wallet configured'}
          </div>
        )}

        {/* Address + copy */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 10, color: '#5a6478', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>Address</div>
          <div
            onClick={() => setShowFull((s) => !s)}
            style={{
              fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#e8eaf0',
              wordBreak: 'break-all', cursor: 'pointer', lineHeight: 1.7,
              background: '#0d1015', padding: '8px 10px', borderRadius: 6, border: '1px solid #1e2530',
            }}
            title="Click to toggle full address"
          >
            {showFull ? wallet : shortAddr}
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
            <button
              onClick={() => wallet && copyToClipboard(wallet, setCopied)}
              style={{
                background: copied ? '#00e67622' : 'transparent', color: copied ? '#00e676' : '#8b95a8',
                border: `1px solid ${copied ? '#00e676' : '#1e2530'}`, borderRadius: 6,
                padding: '5px 12px', fontSize: 12, cursor: 'pointer', fontFamily: 'JetBrains Mono, monospace',
                transition: 'all 0.2s ease',
              }}
            >
              {copied ? '✓ Copied' : 'Copy address'}
            </button>
          </div>

          {/* Compact payout summary */}
          <div style={{ marginTop: 12, display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            <Stat label="Pending" value={pool.pending_balance != null ? `${pool.pending_balance.toFixed(6)} ${coin}` : '—'} color={color} />
            <Stat label="Total paid" value={pool.paid_total != null ? `${pool.paid_total.toFixed(4)} ${coin}` : '—'} />
            <Stat label="Last payout" value={payouts[0] ? fmt_coin(payouts[0].amount, 4) + ` ${coin}` : '—'} />
          </div>
        </div>
      </div>
    </Card>
  );
}

const Stat = ({ label, value, color }) => (
  <div>
    <div style={{ fontSize: 10, color: '#5a6478', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>{label}</div>
    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, color: color || '#e8eaf0' }}>{value}</div>
  </div>
);

const Row = ({ k, v }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #181d25', fontSize: '13px' }}>
    <span style={{ color: '#8b95a8' }}>{k}</span>
    <span style={{ fontFamily: 'JetBrains Mono, monospace', color: '#e8eaf0', wordBreak: 'break-all', textAlign: 'right', maxWidth: '70%' }}>{v}</span>
  </div>
);

export default function Settings() {
  const { stats, actionPending, startMining } = useMiningData();
  if (!stats) return <div style={{ padding: 40, color: '#5a6478' }}>Connecting…</div>;
  const color = coinColor(stats.coin);
  const pool = stats.pool || {};

  return (
    <div style={{ maxWidth: '1300px', margin: '0 auto', padding: '32px 32px 60px' }}>
      <h1 style={{ fontSize: '22px', fontWeight: 800, margin: '0 0 24px' }}>Settings</h1>

      <WalletCard coin={stats.coin} wallet={stats.wallet} pool={pool} color={color} />

      <div style={{ marginTop: 16 }}>
        <Card title="Coin Selection">
          <div style={{ fontSize: 13, color: '#8b95a8', marginBottom: 14 }}>
            Wallet addresses are read from each coin's config file in <code>configs/</code> — change
            a wallet by editing that file directly, then restart the backend.
          </div>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            {(stats.available_coins || []).map((c) => (
              <button
                key={c.key}
                onClick={() => startMining(c.key).catch(() => {})}
                disabled={actionPending}
                style={{
                  padding: '12px 16px', borderRadius: 8, cursor: 'pointer',
                  border: `1.5px solid ${stats.coin === c.key ? coinColor(c.key) : '#1e2530'}`,
                  background: stats.coin === c.key ? `${coinColor(c.key)}15` : '#0d1015',
                  color: stats.coin === c.key ? coinColor(c.key) : '#8b95a8',
                  fontFamily: 'JetBrains Mono, monospace', textAlign: 'left', minWidth: 140,
                }}
              >
                <div style={{ fontWeight: 700, fontSize: 14 }}>{c.key}</div>
                <div style={{ fontSize: 11, marginTop: 4 }}>{c.algo}</div>
                <div style={{ fontSize: 11, marginTop: 2, opacity: 0.7 }}>via {c.pool_provider}</div>
              </button>
            ))}
          </div>
        </Card>
      </div>

      <div style={{ marginTop: 16 }}>
        <Card title="Active Configuration">
          <Row k="Coin" v={stats.coin} />
          <Row k="Algorithm" v={stats.algo} />
          <Row k="Pool Provider" v={(stats.available_coins || []).find(c => c.key === stats.coin)?.pool_provider} />
          <Row k="Power Cost" v={`${stats.profitability?.power_cost_per_kwh ?? 0} $/kWh · edit configs/rig.json to change`} />
        </Card>
      </div>
    </div>
  );
}
