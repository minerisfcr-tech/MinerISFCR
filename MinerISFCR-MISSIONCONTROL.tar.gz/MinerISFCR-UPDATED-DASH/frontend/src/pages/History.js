import React, { useEffect, useState, useCallback } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { API_BASE } from '../context/MiningDataContext';
import { useMiningData } from '../context/MiningDataContext';
import { Card, EmptyState } from '../components/UIPrimitives';
import { coinColor } from '../utils/format';

const RANGE_OPTIONS = [
  { label: '1h', hours: 1 },
  { label: '6h', hours: 6 },
  { label: '24h', hours: 24 },
  { label: '7d', hours: 24 * 7 },
];

export default function History() {
  const { stats } = useMiningData();
  const activeCoin = stats?.coin || '';
  const [hours, setHours] = useState(24);
  const [coin, setCoin] = useState(activeCoin);
  const [rows, setRows] = useState([]);
  const [availableCoins, setAvailableCoins] = useState([]);
  const [loading, setLoading] = useState(true);

  // Default the coin selector to the currently-active coin whenever it changes.
  useEffect(() => {
    if (activeCoin && !coin) setCoin(activeCoin);
  }, [activeCoin, coin]);

  const fetchHistory = useCallback(async () => {
    setLoading(true);
    try {
      const coinParam = coin ? `&coin=${encodeURIComponent(coin)}` : '';
      const res = await fetch(`${API_BASE}/history/snapshots?hours=${hours}${coinParam}`);
      const data = await res.json();

      // Format timestamps and derive a label for the time axis.
      const formatted = (data.snapshots || []).map((s) => ({
        ...s,
        time: new Date(s.ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        // Omit null/zero-sentinel values from the chart rather than charting
        // them as false zero-crossings (this was the root cause of the
        // "suspicious dips to zero" chart artefacts seen in the old version).
        hashrate_1m: s.hashrate_1m || null,
        gpu_temp: s.gpu_temp || null,
        gpu_power_draw: s.gpu_power_draw || null,
        cpu_usage_percent: s.cpu_usage_percent || null,
        price_usd: s.price_usd || null,
        revenue_usd_per_day: s.revenue_usd_per_day || null,
        // Use the delta columns (shares this interval, never cumulative) so
        // a miner restart doesn't look like the chart "resetting to zero."
        shares_rate: s.accepted_shares_delta != null ? s.accepted_shares_delta : null,
      }));

      setRows(formatted);
      if (data.available_coins) setAvailableCoins(data.available_coins);
    } catch (_) {}
    setLoading(false);
  }, [hours, coin]);

  useEffect(() => {
    fetchHistory();
    const t = setInterval(fetchHistory, 30000);
    return () => clearInterval(t);
  }, [fetchHistory]);

  const color = coinColor(coin || activeCoin);

  return (
    <div style={{ maxWidth: '1300px', margin: '0 auto', padding: '32px 32px 60px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', flexWrap: 'wrap', gap: 12 }}>
        <h1 style={{ fontSize: '22px', fontWeight: 800, margin: 0 }}>Historical Analytics</h1>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
          {/* Coin selector — each coin has its own hashrate scale and price,
              so mixing them in one series produces misleading artefacts. */}
          {availableCoins.length > 1 && (
            <select
              value={coin}
              onChange={(e) => setCoin(e.target.value)}
              style={{
                background: '#0d1015', color: '#e8eaf0', border: `1px solid ${color}`,
                borderRadius: '6px', padding: '6px 12px', fontSize: '12px',
                cursor: 'pointer', fontFamily: 'JetBrains Mono, monospace',
              }}
            >
              <option value="">All coins</option>
              {availableCoins.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          )}
          {RANGE_OPTIONS.map((opt) => (
            <button key={opt.label} onClick={() => setHours(opt.hours)} style={{
              background: hours === opt.hours ? '#00e676' : 'transparent',
              color: hours === opt.hours ? '#0a0d12' : '#8b95a8',
              border: '1px solid #1e2530', borderRadius: '6px', padding: '6px 12px',
              fontSize: '12px', cursor: 'pointer', fontFamily: 'JetBrains Mono, monospace',
            }}>{opt.label}</button>
          ))}
        </div>
      </div>

      {coin && (
        <div style={{ fontSize: 12, color: '#5a6478', marginBottom: 16 }}>
          Showing data for <span style={{ color, fontWeight: 700 }}>{coin}</span>.
          {availableCoins.length > 1 && ' Use the selector above to switch coins — different coins mine at different hashrate scales and prices, so mixing them in one chart produces misleading-looking artefacts.'}
        </div>
      )}

      {loading && rows.length === 0 ? (
        <div style={{ color: '#5a6478' }}>Loading history…</div>
      ) : rows.length === 0 ? (
        <EmptyState message="No history yet for this coin / time range. The backend logs one snapshot per minute while mining." />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
          <Card title="Hashrate Trend (H/s)">
            <Chart data={rows} dataKey="hashrate_1m" color={color} />
          </Card>
          <Card title="Shares Accepted (per interval)">
            <Chart data={rows} dataKey="shares_rate" color="#00e676" />
            <div style={{ fontSize: 11, color: '#5a6478', marginTop: 8 }}>
              Counts shares accepted in each 1-minute window — never cumulative, so a miner restart shows as "0" for that interval rather than a false cliff back to zero.
            </div>
          </Card>
          <Card title={coin === 'XMR' ? 'CPU Usage Trend (%)' : 'GPU Temperature Trend (°C)'}>
            <Chart data={rows} dataKey={coin === 'XMR' ? 'cpu_usage_percent' : 'gpu_temp'} color="#ff6600" />
          </Card>
          <Card title="GPU Power Draw Trend (W)">
            <Chart data={rows} dataKey="gpu_power_draw" color="#2196f3" />
            {coin === 'XMR' && (
              <div style={{ fontSize: 11, color: '#5a6478', marginTop: 8 }}>
                XMR (RandomX) mines on the CPU — GPU power draw will be near zero during this coin. That's expected.
              </div>
            )}
          </Card>
          <Card title="Coin Price Trend (USD)">
            <Chart data={rows} dataKey="price_usd" color="#ffca28" />
          </Card>
          <Card title="Estimated Revenue / Day (USD)">
            <Chart data={rows} dataKey="revenue_usd_per_day" color="#00e676" />
          </Card>
        </div>
      )}
    </div>
  );
}

function Chart({ data, dataKey, color }) {
  // Filter out nulls so Recharts doesn't draw a line down to zero.
  const filtered = data.filter((d) => d[dataKey] != null);
  if (filtered.length === 0) {
    return <div style={{ color: '#5a6478', fontSize: 12, padding: '20px 0' }}>No data for this metric in the selected window.</div>;
  }
  return (
    <ResponsiveContainer width="100%" height={220}>
      <LineChart data={filtered} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#1e2530" />
        <XAxis dataKey="time" stroke="#5a6478" fontSize={11} tick={{ fill: '#5a6478' }} />
        <YAxis stroke="#5a6478" fontSize={11} tick={{ fill: '#5a6478' }} />
        <Tooltip contentStyle={{ background: '#0d1015', border: '1px solid #1e2530', fontSize: 12 }} labelStyle={{ color: '#8b95a8' }} />
        <Line type="monotone" dataKey={dataKey} stroke={color} strokeWidth={2} dot={false} isAnimationActive={false} connectNulls={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}
