import React from 'react';
import { useMiningData } from '../context/MiningDataContext';
import { Card, ErrorBanner } from '../components/UIPrimitives';
import { fmt_hash, fmt_usd, fmt_coin } from '../utils/format';

export default function Profitability() {
  const { stats, errors } = useMiningData();
  if (!stats) return <div style={{ padding: 40, color: '#5a6478' }}>Connecting…</div>;
  const gpu = stats.gpu || {};
  const xmrig = stats.xmrig || {};
  const network = stats.network || {};
  const profit = stats.profitability || {};

  const netProfit = profit.net_profit_per_day_usd;
  const netProfitColor = netProfit > 0 ? '#00e676' : netProfit < 0 ? '#ff1744' : undefined;
  const missingNetworkData = !network.network_hashrate || !network.block_reward;

  return (
    <div style={{ maxWidth: '1300px', margin: '0 auto', padding: '32px 32px 60px' }}>
      <h1 style={{ fontSize: '22px', fontWeight: 800, margin: '0 0 8px' }}>Profitability</h1>
      <div style={{ fontSize: '13px', color: '#5a6478', marginBottom: '24px' }}>
        Recalculated every 2 seconds from live hashrate, network data and coin price.
      </div>
      <ErrorBanner errors={errors} />

      {missingNetworkData && (
        <div style={{
          background: '#1a1408', border: '1px solid #5a4a10', borderRadius: '8px',
          padding: '10px 14px', marginBottom: '20px', fontSize: '13px', color: '#e8d088',
        }}>
          {stats.coin === 'ALPH'
            ? "Alephium's block reward is recalculated by the protocol on every single block (no fixed schedule) and there's no simple public API for it, so Estimated Coins/Day, Revenue and Net Profit are left blank for ALPH rather than guessed. Hashrate-per-watt below doesn't depend on that and still works."
            : "Waiting on network hashrate / block reward data for this coin — figures below will fill in once that arrives."}
        </div>
      )}

      <Card title="Revenue & Cost">
        <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
          <Metric label="Estimated Coins / day" value={fmt_coin(profit.coins_per_day_est, 6)} />
          <Metric label="Revenue / day" value={fmt_usd(profit.revenue_usd_per_day, 2)} color="#00e676" />
          <Metric label="Power Cost / day" value={fmt_usd(profit.power_cost_per_day_usd, 2)} />
          <Metric label="Net Profit / day" value={fmt_usd(netProfit, 2)} color={netProfitColor} />
        </div>
      </Card>

      <div style={{ marginTop: '16px' }}>
        <Card title="Efficiency">
          <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
            <Metric label="Hashrate" value={fmt_hash(xmrig.hashrate_1m)} />
            <Metric label="Power Draw" value={gpu.power_draw ? `${gpu.power_draw.toFixed(0)} W` : '—'} />
            <Metric label="Hashrate per Watt" value={profit.hashrate_per_watt ? `${profit.hashrate_per_watt.toFixed(2)} H/W` : '—'} />
            <Metric label="Revenue per Watt" value={fmt_usd(profit.revenue_per_watt_usd, 4)} />
          </div>
        </Card>
      </div>

      <div style={{ marginTop: '16px', fontSize: '12px', color: '#5a6478' }}>
        Power cost is currently set to {fmt_usd(profit.power_cost_per_kwh, 2)}/kWh. Edit{' '}
        <code style={{ color: '#8b95a8' }}>configs/rig.json</code> on the rig to match your real electricity
        tariff — Net Profit will update automatically on the next refresh.
      </div>
    </div>
  );
}

const Metric = ({ label, value, color }) => (
  <div style={{ background: '#0d1015', border: '1px solid #1e2530', borderRadius: '8px', padding: '14px 16px', minWidth: '150px' }}>
    <div style={{ fontSize: '10px', color: '#5a6478', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '6px' }}>{label}</div>
    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '18px', fontWeight: 700, color: color || '#e8eaf0' }}>{value}</div>
  </div>
);
