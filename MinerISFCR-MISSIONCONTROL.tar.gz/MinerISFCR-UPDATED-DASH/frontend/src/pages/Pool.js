import React from 'react';
import { useMiningData } from '../context/MiningDataContext';
import { Card, ErrorBanner, Badge } from '../components/UIPrimitives';
import { fmt_hash, fmt_coin, coinColor } from '../utils/format';

const Row = ({ k, v, color, tip }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: '1px solid #181d25', fontSize: '13px' }} title={tip}>
    <span style={{ color: '#8b95a8' }}>{k}</span>
    <span style={{ fontFamily: 'JetBrains Mono, monospace', color: color || '#e8eaf0' }}>{v}</span>
  </div>
);

function toDate(value) {
  if (!value) return null;
  return typeof value === 'number' ? new Date(value * 1000) : new Date(value);
}

export default function Pool() {
  const { stats, errors } = useMiningData();
  if (!stats) return <div style={{ padding: 40, color: '#5a6478' }}>Connecting…</div>;
  const pool = stats.pool || {};
  const xmrig = stats.xmrig || {};
  const color = coinColor(stats.coin);

  const luckColor = (pct) => {
    if (pct == null) return undefined;
    if (pct > 100) return '#ff8a65'; // unlucky round
    if (pct > 80) return '#00e676';  // good round
    return '#ffca28';                // neutral
  };

  const payouts = pool.payout_history || [];

  return (
    <div style={{ maxWidth: '1300px', margin: '0 auto', padding: '32px 32px 60px' }}>
      <h1 style={{ fontSize: '22px', fontWeight: 800, margin: '0 0 8px' }}>Pool Metrics</h1>
      <div style={{ fontSize: '13px', color: '#5a6478', marginBottom: '24px' }}>
        {stats.coin} via <span style={{ color }}>{pool.pool_name}</span> · wallet {stats.wallet ? `${stats.wallet.slice(0, 10)}…${stats.wallet.slice(-6)}` : '—'}
      </div>
      <ErrorBanner errors={errors} />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px' }}>
        <Card title="Miner Metrics">
          <Row k="Status" v={stats.running ? 'Running' : 'Stopped'} color={stats.running ? '#00e676' : '#5a6478'} />
          <Row k="Coin" v={stats.coin} />
          <Row k="Algorithm" v={stats.algo} />
          <Row k="Pool Connected" v={xmrig.connected ? 'Yes' : 'No'} color={xmrig.connected ? '#00e676' : '#ff1744'} />
          <Row k="Current Hashrate" v={fmt_hash(xmrig.hashrate_1m)} />
          <Row k="Avg 10m" v={fmt_hash(xmrig.hashrate_10m)} />
          <Row k="Avg 1h" v={fmt_hash(xmrig.hashrate_1h)} />
          <Row k="Miner Uptime" v={xmrig.uptime ? `${Math.floor(xmrig.uptime / 3600)}h ${Math.floor((xmrig.uptime % 3600) / 60)}m` : '—'} />
          <Row k="Accepted Shares" v={xmrig.accepted_shares ?? '—'} color="#00e676" />
          <Row k="Rejected Shares" v={xmrig.rejected_shares ?? '—'} color={xmrig.rejected_shares > 0 ? '#ff1744' : undefined} />
          <Row k="Share Difficulty" v={xmrig.difficulty ? xmrig.difficulty.toLocaleString() : '—'}
            tip="The target difficulty for each share submitted to the pool. Higher = harder shares that count for more of the block." />
        </Card>

        <Card title="Pool-Side Metrics">
          {!pool.reachable && (
            <div style={{ marginBottom: 12 }}>
              <Badge color="#ff8a65" bg="#2a1410">{pool.error || 'Pool unreachable'}</Badge>
            </div>
          )}
          <Row k="Pool Hashrate" v={fmt_hash(pool.pool_hashrate)} />
          <Row k="Effective Hashrate" v={fmt_hash(pool.effective_hashrate)} />
          <Row k="Worker Status" v={pool.worker_status} color={pool.worker_status === 'online' ? color : '#5a6478'} />
          <Row k="Workers Online" v={pool.workers_online ?? '—'} />
          <Row k="API Latency" v={pool.latency_ms != null ? `${pool.latency_ms.toFixed(0)} ms` : '—'}
            tip="Round-trip time to the pool's API server. Doesn't directly affect mining (that's pool stratum latency), but high values here mean the dashboard takes longer to update." />
          <Row k="Pool Luck (this round)"
            v={pool.pool_luck_percent != null ? `${pool.pool_luck_percent.toFixed(1)}%` : '—'}
            color={luckColor(pool.pool_luck_percent)}
            tip="How much of the current round's block-reward work your shares represent vs. the pool's combined total. Over 100% = you've been unlucky this round (the pool hasn't found a block yet even though statistically it should have)." />
          <Row k="Pending Balance" v={pool.pending_balance !== undefined ? pool.pending_balance.toFixed(8) : '—'} />
          <Row k="Immature Balance" v={pool.immature_balance !== undefined ? pool.immature_balance.toFixed(8) : '—'} />
          <Row k="Total Paid" v={pool.paid_total !== undefined ? pool.paid_total.toFixed(6) : '—'} />
          <Row k="Pool Fee" v={pool.pool_fee_percent != null ? `${pool.pool_fee_percent}%` : 'See pool website'} />
        </Card>
      </div>

      {payouts.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <Card title="Payout History (this wallet, most recent first)">
            <table style={{ width: '100%', fontSize: 13, borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', color: '#5a6478', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  <th style={{ padding: '6px 0' }}>Amount</th>
                  <th>When</th>
                  <th>Tx</th>
                </tr>
              </thead>
              <tbody>
                {payouts.slice(0, 10).map((p, i) => {
                  const d = toDate(p.timestamp);
                  return (
                    <tr key={i} style={{ borderTop: '1px solid #181d25' }}>
                      <td style={{ padding: '8px 0', color, fontFamily: 'JetBrains Mono, monospace' }}>
                        {fmt_coin(p.amount, 6)} {stats.coin}
                      </td>
                      <td style={{ color: '#8b95a8' }}>
                        {d ? d.toLocaleString() : '—'}
                      </td>
                      <td style={{ color: '#5a6478', fontSize: 12 }}>
                        {p.tx ? `${p.tx.slice(0, 10)}…` : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>
        </div>
      )}
    </div>
  );
}
