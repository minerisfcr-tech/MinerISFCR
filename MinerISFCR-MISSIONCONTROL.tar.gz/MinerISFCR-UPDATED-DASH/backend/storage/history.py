"""
Lightweight historical storage for the ISFCR Mining Console.

Uses SQLite (stdlib, zero extra deps) so the dashboard's history/analytics
pages have real trend data to chart, and so a detected block stays recorded
even across backend restarts.

Three tables:
  snapshots    -- one row per periodic sample (hashrate, temps, power, shares...)
  blocks_found -- one row every time we detect our address found a block
  events       -- the live activity feed: share accepted/rejected, payouts,
                  pool connect/disconnect, miner start/stop, block found
"""
import json
import sqlite3
import threading
import time
from pathlib import Path
from datetime import datetime, timedelta

DB_PATH = Path(__file__).resolve().parent.parent.parent / "logs" / "history.sqlite3"
DB_PATH.parent.mkdir(exist_ok=True)

_lock = threading.Lock()


def _connect():
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _column_exists(conn, table, column) -> bool:
    cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
    return column in cols


def init_db():
    with _lock, _connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                coin TEXT,
                hashrate_1m REAL,
                accepted_shares INTEGER,
                rejected_shares INTEGER,
                pool_connected INTEGER,
                gpu_temp REAL,
                gpu_hotspot_temp REAL,
                gpu_power_draw REAL,
                cpu_temp REAL,
                cpu_usage_percent REAL,
                price_usd REAL,
                revenue_usd_per_day REAL
            )
        """)
        # Added later: reset-safe per-interval share counts, so charts plot a
        # rate (always >= 0) instead of a cumulative counter that cliffs to
        # zero every time the miner process restarts. ALTER TABLE rather than
        # recreating, so existing history.sqlite3 files on a running rig
        # upgrade in place without losing data.
        if not _column_exists(conn, "snapshots", "accepted_shares_delta"):
            conn.execute("ALTER TABLE snapshots ADD COLUMN accepted_shares_delta INTEGER")
        if not _column_exists(conn, "snapshots", "rejected_shares_delta"):
            conn.execute("ALTER TABLE snapshots ADD COLUMN rejected_shares_delta INTEGER")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_snapshots_ts ON snapshots(ts)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_snapshots_coin_ts ON snapshots(coin, ts)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS blocks_found (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                coin TEXT,
                pool_name TEXT,
                block_height INTEGER,
                reward_estimate REAL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_blocks_ts ON blocks_found(ts)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                coin TEXT,
                event_type TEXT NOT NULL,
                message TEXT,
                data_json TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts)")
        conn.commit()


def insert_snapshot(coin: str, hashrate_1m: float, accepted: int, rejected: int,
                     pool_connected: bool, gpu_temp: float, gpu_hotspot_temp: float,
                     gpu_power_draw: float, cpu_temp: float, cpu_usage_percent: float,
                     price_usd: float | None, revenue_usd_per_day: float | None,
                     accepted_delta: int = 0, rejected_delta: int = 0):
    with _lock, _connect() as conn:
        conn.execute(
            """INSERT INTO snapshots
               (ts, coin, hashrate_1m, accepted_shares, rejected_shares, pool_connected,
                gpu_temp, gpu_hotspot_temp, gpu_power_draw, cpu_temp, cpu_usage_percent,
                price_usd, revenue_usd_per_day, accepted_shares_delta, rejected_shares_delta)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (int(time.time()), coin, hashrate_1m, accepted, rejected, int(pool_connected),
             gpu_temp, gpu_hotspot_temp, gpu_power_draw, cpu_temp, cpu_usage_percent,
             price_usd, revenue_usd_per_day, accepted_delta, rejected_delta),
        )
        conn.commit()


def get_snapshots_since(hours: float = 24.0, limit: int = 2000, coin: str | None = None) -> list[dict]:
    """Filtering by coin matters: different coins mine at wildly different
    hashrate scales and prices, so mixing them in one chronological series
    produces fake-looking cliffs that aren't actually bad data — they're just
    two unrelated series plotted as if they were one."""
    cutoff = int(time.time() - hours * 3600)
    with _lock, _connect() as conn:
        if coin:
            rows = conn.execute(
                "SELECT * FROM snapshots WHERE ts >= ? AND coin = ? ORDER BY ts ASC LIMIT ?",
                (cutoff, coin, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM snapshots WHERE ts >= ? ORDER BY ts ASC LIMIT ?",
                (cutoff, limit),
            ).fetchall()
        return [dict(r) for r in rows]


def get_snapshot_coins_in_range(hours: float = 24.0) -> list[str]:
    """Which coins actually have history in this window — drives the coin
    selector on the History page so users aren't offered empty options."""
    cutoff = int(time.time() - hours * 3600)
    with _lock, _connect() as conn:
        rows = conn.execute(
            "SELECT DISTINCT coin FROM snapshots WHERE ts >= ? AND coin IS NOT NULL", (cutoff,)
        ).fetchall()
        return [r[0] for r in rows]


def insert_block_found(coin: str, pool_name: str, block_height: int | None, reward_estimate: float | None):
    with _lock, _connect() as conn:
        conn.execute(
            "INSERT INTO blocks_found (ts, coin, pool_name, block_height, reward_estimate) VALUES (?,?,?,?,?)",
            (int(time.time()), coin, pool_name, block_height, reward_estimate),
        )
        conn.commit()


def get_blocks_found(limit: int = 50) -> list[dict]:
    with _lock, _connect() as conn:
        rows = conn.execute(
            "SELECT * FROM blocks_found ORDER BY ts DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def insert_event(coin: str | None, event_type: str, message: str, data: dict | None = None) -> dict:
    ts = int(time.time())
    data_json = json.dumps(data) if data else None
    with _lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO events (ts, coin, event_type, message, data_json) VALUES (?,?,?,?,?)",
            (ts, coin, event_type, message, data_json),
        )
        conn.commit()
        return {"id": cur.lastrowid, "ts": ts, "coin": coin, "event_type": event_type, "message": message, "data": data}


def get_recent_events(limit: int = 50, coin: str | None = None) -> list[dict]:
    with _lock, _connect() as conn:
        if coin:
            rows = conn.execute(
                "SELECT * FROM events WHERE coin = ? ORDER BY ts DESC LIMIT ?", (coin, limit)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM events ORDER BY ts DESC LIMIT ?", (limit,)
            ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            if d.get("data_json"):
                try:
                    d["data"] = json.loads(d["data_json"])
                except Exception:
                    d["data"] = None
            else:
                d["data"] = None
            del d["data_json"]
            out.append(d)
        return out


def prune_old_snapshots(days: int = 30):
    """Keep the DB from growing unbounded; called occasionally by the periodic task."""
    cutoff = int(time.time() - days * 86400)
    with _lock, _connect() as conn:
        conn.execute("DELETE FROM snapshots WHERE ts < ?", (cutoff,))
        conn.execute("DELETE FROM events WHERE ts < ?", (cutoff,))
        conn.commit()


init_db()
