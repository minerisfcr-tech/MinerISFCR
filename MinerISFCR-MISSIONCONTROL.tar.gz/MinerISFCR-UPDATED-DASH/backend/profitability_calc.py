"""
Profitability + Block Discovery math. Kept in its own module, separate
from main.py and from the pool/network API clients, so the fix for these
two tabs touches as little of the existing (working) codebase as possible.

Both functions are pure and defensive: any missing input (most commonly
network_hashrate or block_reward, which not every pool API exposes for
every coin) makes the dependent output None instead of a fabricated
number. "N/A" on screen is correct when the data isn't there; a wrong
number is not.
"""
import json
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
RIG_CONFIG_PATH = REPO_ROOT / "configs" / "rig.json"

_DEFAULT_RIG_CONFIG = {
    "power_cost_per_kwh": 0.0,
    "currency": "USD",
}


def load_rig_config() -> dict:
    """Power cost isn't known by this project (it depends on the user's real
    electricity tariff), so it lives in its own small config file rather than
    being guessed. Defaults to 0, which makes Net Profit == Revenue until set —
    an honest default, not a wrong one."""
    cfg = dict(_DEFAULT_RIG_CONFIG)
    try:
        data = json.loads(RIG_CONFIG_PATH.read_text())
        cfg.update({k: v for k, v in data.items() if not k.startswith("_")})
    except Exception:
        pass
    return cfg


def _safe_div(a, b):
    try:
        if a is None or b is None or b == 0:
            return None
        return a / b
    except (TypeError, ZeroDivisionError):
        return None


def compute_profitability(
    my_hashrate: float,
    network_hashrate,
    block_reward,
    block_time_seconds,
    price_usd,
    pool_fee_pct,
    power_draw_watts,
    power_cost_per_kwh: float,
) -> dict:
    """
    Standard "my hashrate's fair share of all blocks" model:
        blocks_per_day      = 86400 / block_time
        my_share_of_network = my_hashrate / network_hashrate
        coins_per_day       = my_share_of_network * blocks_per_day * block_reward * (1 - fee)
    """
    out = {
        "estimated_coins_per_day": None,
        "revenue_per_day_usd": None,
        "power_cost_per_day_usd": None,
        "net_profit_per_day_usd": None,
        "hashrate_per_watt": None,
        "revenue_per_watt_usd": None,
    }

    network_share = _safe_div(my_hashrate, network_hashrate) if my_hashrate else None
    blocks_per_day = _safe_div(86400, block_time_seconds)

    coins_per_day = None
    if network_share is not None and blocks_per_day is not None and block_reward is not None:
        fee_factor = 1 - ((pool_fee_pct or 0) / 100)
        coins_per_day = network_share * blocks_per_day * block_reward * fee_factor
        out["estimated_coins_per_day"] = coins_per_day

    revenue_per_day = None
    if coins_per_day is not None and price_usd is not None:
        revenue_per_day = coins_per_day * price_usd
        out["revenue_per_day_usd"] = revenue_per_day

    power_cost_per_day = None
    if power_draw_watts:
        power_cost_per_day = (power_draw_watts / 1000) * 24 * (power_cost_per_kwh or 0)
        out["power_cost_per_day_usd"] = power_cost_per_day

    if revenue_per_day is not None and power_cost_per_day is not None:
        out["net_profit_per_day_usd"] = revenue_per_day - power_cost_per_day
    elif revenue_per_day is not None:
        out["net_profit_per_day_usd"] = revenue_per_day  # power cost not configured yet

    if power_draw_watts:
        out["hashrate_per_watt"] = _safe_div(my_hashrate, power_draw_watts)
        if revenue_per_day is not None:
            out["revenue_per_watt_usd"] = _safe_div(revenue_per_day, power_draw_watts)

    return out


def _humanize_seconds(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    minutes = seconds / 60
    if minutes < 60:
        return f"{minutes:.1f} min"
    hours = minutes / 60
    if hours < 24:
        return f"{hours:.1f} hours"
    days = hours / 24
    if days < 365:
        return f"{days:.1f} days"
    years = days / 365.25
    return f"{years:.1f} years"


def compute_block_discovery(my_hashrate: float, network_hashrate, block_time_seconds) -> dict:
    """
    "If this were solo mining" numbers. PPLNS pools smooth this out (you're
    paid from the pool's combined luck, not a personal lottery), which is
    exactly why these come out huge for one rig's worth of hashrate — that's
    expected, not a bug.
    """
    out = {
        "network_share_pct": None,
        "probability_per_block_pct": None,
        "expected_solo_block_time_seconds": None,
        "expected_solo_block_time_human": None,
    }
    if not my_hashrate or not network_hashrate:
        return out

    share = my_hashrate / network_hashrate
    out["network_share_pct"] = share * 100
    out["probability_per_block_pct"] = share * 100

    if block_time_seconds and share > 0:
        seconds = block_time_seconds / share
        out["expected_solo_block_time_seconds"] = seconds
        out["expected_solo_block_time_human"] = _humanize_seconds(seconds)

    return out
