"""
Network-level stats: network hashrate, network difficulty, current block
height, current block reward, average block time. NOT pool-side, NOT your
numbers -- these feed the Profitability and Block Discovery tabs.

The previous version of this module tried to guess these out of each
pool's own /api/stats response, which turned out to not reliably expose
network_hashrate or block_reward at all (the relevant line always
evaluated to None) -- that's the root cause both of those tabs never
updated. This version uses sources confirmed live, by direct fetch,
to actually carry these fields:

  - ETC, RVN, ERG:  https://whattomine.com/coins.json  (free, no-auth,
                     long-standing public endpoint used by many mining
                     dashboards; confirmed fields: nethash, difficulty,
                     last_block, block_reward, block_time, market_cap)
  - XMR:            https://localmonero.co/blocks/api/get_stats  (free,
                     no-auth Monero explorer; confirmed fields: height,
                     difficulty, hashrate, last_reward)
  - ALPH:           HeroMiners' stats_address response already carries
                     networkHeight (kept as before). Alephium's block
                     reward is recalculated by the protocol on every
                     single block from live network hashrate + timestamp
                     (no halving schedule) and there's no simple public
                     API for it, so it's left None rather than guessed --
                     same honesty policy as everywhere else in this file.
"""
import time
import logging
import httpx

logger = logging.getLogger("isfcr-mining-console.network")

HTTP_TIMEOUT = 8.0

WHATTOMINE_KEYS = {
    "ETC": "EthereumClassic",
    "RVN": "Ravencoin",
    "ERG": "Ergo",
}

_wtm_cache: dict = {}
_wtm_cache_ts: float = 0.0
WTM_TTL_SECONDS = 180  # one big shared fetch every 3 min covers all three coins

_xmr_cache: dict = {}
_xmr_cache_ts: float = 0.0
XMR_TTL_SECONDS = 30


def _empty_network_stats() -> dict:
    return {
        "network_hashrate": None,
        "network_difficulty": None,
        "block_height": None,
        "block_reward": None,
        "block_time_seconds": None,
        "pool_hashrate_total": None,
        "miners_count": None,
    }


async def _fetch_whattomine() -> dict:
    """One shared fetch covers ETC + RVN + ERG -- cached so we hit this at most
    once every 3 minutes regardless of how many of those coins are active."""
    global _wtm_cache, _wtm_cache_ts
    now = time.monotonic()
    if _wtm_cache and (now - _wtm_cache_ts) < WTM_TTL_SECONDS:
        return _wtm_cache
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            resp = await client.get("https://whattomine.com/coins.json")
            resp.raise_for_status()
            data = resp.json().get("coins", {})
        if data:
            _wtm_cache = data
            _wtm_cache_ts = now
        return data or _wtm_cache
    except Exception as e:
        logger.warning("whattomine.com/coins.json unreachable: %s", e)
        return _wtm_cache  # serve stale cache rather than nothing


def _parse_market_cap(value):
    if not value:
        return None
    try:
        return float(str(value).replace("$", "").replace(",", ""))
    except ValueError:
        return None


async def fetch_2miners_network_stats(coin_key: str) -> dict:
    result = _empty_network_stats()
    key = WHATTOMINE_KEYS.get(coin_key)
    if not key:
        return result
    coins = await _fetch_whattomine()
    entry = coins.get(key)
    if not entry:
        warned = getattr(fetch_2miners_network_stats, "_warned", set())
        if coin_key not in warned:
            logger.warning("whattomine.com has no entry named '%s' for coin %s", key, coin_key)
            warned.add(coin_key)
            fetch_2miners_network_stats._warned = warned
        return result
    try:
        result["network_hashrate"] = entry.get("nethash")
        result["network_difficulty"] = entry.get("difficulty")
        result["block_height"] = entry.get("last_block")
        result["block_reward"] = entry.get("block_reward")
        block_time = entry.get("block_time")
        result["block_time_seconds"] = float(block_time) if block_time else None
        result["_market_cap_usd"] = _parse_market_cap(entry.get("market_cap"))
    except Exception:
        logger.exception("Failed parsing whattomine entry for %s", coin_key)
    return result


async def fetch_herominers_network_stats(coin_subdomain: str, wallet: str) -> dict:
    """HeroMiners doesn't have a documented no-address /stats endpoint; reusing
    stats_address (works with any address, even one with zero history) since
    its response carries networkHeight regardless of whose address is queried."""
    result = _empty_network_stats()
    url = f"https://{coin_subdomain}.herominers.com/api/stats_address"
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            resp = await client.get(url, params={"address": wallet} if wallet else {})
            resp.raise_for_status()
            data = resp.json()
        s = data.get("stats", {}) or {}
        result["block_height"] = s.get("networkHeight")
        result["pool_hashrate_total"] = s.get("poolRoundHashes")
    except Exception as e:
        logger.warning("HeroMiners network stats unreachable for %s: %s", coin_subdomain, e)
    return result


async def fetch_moneroocean_network_stats() -> dict:
    """MoneroOcean's miner endpoint doesn't expose XMR network difficulty/height,
    so this goes to a dedicated, free, no-auth Monero explorer API instead --
    independent of the mining pool, same as how a 'Network' tab should work."""
    global _xmr_cache, _xmr_cache_ts
    now = time.monotonic()
    if _xmr_cache and (now - _xmr_cache_ts) < XMR_TTL_SECONDS:
        return _xmr_cache

    result = _empty_network_stats()
    result["block_time_seconds"] = 120  # fixed by the Monero protocol
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            resp = await client.get("https://localmonero.co/blocks/api/get_stats")
            resp.raise_for_status()
            data = resp.json()
        result["network_hashrate"] = data.get("hashrate")
        result["network_difficulty"] = data.get("difficulty")
        result["block_height"] = data.get("height")
        last_reward = data.get("last_reward")
        result["block_reward"] = (last_reward / 1e12) if last_reward else None
        _xmr_cache = result
        _xmr_cache_ts = now
    except Exception as e:
        logger.warning("localmonero.co network stats unreachable: %s", e)
        if _xmr_cache:
            return _xmr_cache
    return result


NETWORK_DISPATCH = {
    "XMR":  {"family": "moneroocean"},
    "ALPH": {"family": "herominers", "subdomain": "alephium"},
    "ETC":  {"family": "2miners"},
    "RVN":  {"family": "2miners"},
    "ERG":  {"family": "2miners"},
}


async def fetch_network_stats(coin_key: str, wallet: str = "") -> dict:
    entry = NETWORK_DISPATCH.get(coin_key)
    if not entry:
        return _empty_network_stats()
    family = entry["family"]
    if family == "moneroocean":
        return await fetch_moneroocean_network_stats()
    elif family == "herominers":
        return await fetch_herominers_network_stats(entry["subdomain"], wallet)
    elif family == "2miners":
        return await fetch_2miners_network_stats(coin_key)
    return _empty_network_stats()
