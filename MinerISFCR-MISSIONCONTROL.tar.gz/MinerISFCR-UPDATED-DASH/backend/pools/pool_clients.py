"""
Pool API clients for ISFCR Mining Console.

Each coin reports to a different pool family:
  XMR  -> MoneroOcean   (api.moneroocean.stream)
  ALPH -> HeroMiners     (alephium.herominers.com/api)
  ETC  -> 2Miners        (etc.2miners.com/api)
  RVN  -> 2Miners        (rvn.2miners.com/api)
  ERG  -> 2Miners        (erg.2miners.com/api)

All three families expose different JSON shapes. This module fetches from
whichever family a coin uses and normalizes the result into a single
PoolStats-shaped dict so the rest of the backend (and the frontend) never
has to know which pool API is behind a given coin.

Normalized shape (all fields always present, defaults applied on failure):
{
    "pool_name": str,
    "reachable": bool,            # did the HTTP call succeed at all
    "pool_hashrate": float,       # H/s as reported for this worker/address by the pool
    "effective_hashrate": float,  # average over the pool's own short window
    "workers_online": int,
    "worker_status": "online" | "offline" | "unknown",
    "pending_balance": float,     # coin units
    "immature_balance": float,
    "paid_total": float,
    "last_payout_ts": int | None, # unix seconds
    "pool_difficulty": float,
    "pool_luck_percent": float | None,
    "pool_fee_percent": float | None,
    "latency_ms": float | None,
    "blocks_found": int,          # blocks this address/worker has found, all-time (from pool data, best-effort)
    "blocks_mined": list,         # [{height, hash, reward, timestamp, percent, orphan}], wallet-scoped, newest first
    "payout_history": list,       # [{amount, timestamp, tx}], wallet-scoped, newest first
    "new_block_height": int | None,   # most recent block height the pool told us about (for block-found detection)
    "raw": dict,                  # original response, for debugging / advanced fields
    "error": str | None,
}
"""
import time
import logging
import httpx

logger = logging.getLogger("isfcr-mining-console.pools")

HTTP_TIMEOUT = 8.0


def _empty_pool_stats(pool_name: str, error: str | None = None) -> dict:
    return {
        "pool_name": pool_name,
        "reachable": False,
        "pool_hashrate": 0.0,
        "effective_hashrate": 0.0,
        "workers_online": 0,
        "worker_status": "unknown",
        "pending_balance": 0.0,
        "immature_balance": 0.0,
        "paid_total": 0.0,
        "last_payout_ts": None,
        "pool_difficulty": 0.0,
        "pool_luck_percent": None,
        "pool_fee_percent": None,
        "latency_ms": None,
        "blocks_found": 0,
        "blocks_mined": [],
        "payout_history": [],
        "new_block_height": None,
        "raw": {},
        "error": error,
    }


async def _timed_get(client: httpx.AsyncClient, url: str, **kwargs):
    start = time.monotonic()
    resp = await client.get(url, **kwargs)
    elapsed_ms = (time.monotonic() - start) * 1000.0
    return resp, elapsed_ms


def _normalize_block_entry(height, hash_, reward_coin_units, timestamp, percent=None, orphan=False) -> dict:
    return {
        "height": height,
        "hash": hash_,
        "reward": reward_coin_units,
        "timestamp": timestamp,
        "percent": percent,
        "orphan": bool(orphan),
    }


# ── MoneroOcean (XMR) ─────────────────────────────────────────────────────
# Docs / community-confirmed endpoint: https://api.moneroocean.stream/miner/<wallet>/stats
async def fetch_moneroocean_stats(wallet: str) -> dict:
    pool_name = "MoneroOcean"
    if not wallet:
        return _empty_pool_stats(pool_name, "No wallet configured")
    url = f"https://api.moneroocean.stream/miner/{wallet}/stats"
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            resp, latency_ms = await _timed_get(client, url)
            resp.raise_for_status()
            data = resp.json()
    except httpx.RequestError as e:
        logger.warning("MoneroOcean API unreachable: %s", e)
        return _empty_pool_stats(pool_name, f"Pool unreachable: {e}")
    except Exception as e:
        logger.warning("MoneroOcean API error: %s", e)
        return _empty_pool_stats(pool_name, f"Pool error: {e}")

    # MoneroOcean's miner/stats response carries fields under varying keys
    # across pool-software versions; we defensively probe several names.
    amt_due = data.get("amtDue", 0) or 0
    amt_paid = data.get("amtPaid", 0) or 0
    hashrate = data.get("hash", data.get("hashrate", 0)) or 0
    hashrate2 = data.get("hash2", hashrate) or hashrate
    last_share_ts = data.get("lastShare")
    workers = data.get("workers", [])
    workers_online = len(workers) if isinstance(workers, list) else (1 if hashrate else 0)

    # amounts on MoneroOcean/cryptonote-pool-style stacks are usually in
    # piconero (1e-12 XMR) — convert defensively only if values look huge.
    def to_xmr(v):
        try:
            v = float(v)
        except (TypeError, ValueError):
            return 0.0
        return v / 1e12 if v > 1e6 else v

    stats = _empty_pool_stats(pool_name)
    stats.update({
        "reachable": True,
        "pool_hashrate": float(hashrate),
        "effective_hashrate": float(hashrate2),
        "workers_online": workers_online,
        "worker_status": "online" if hashrate and hashrate > 0 else ("offline" if last_share_ts else "unknown"),
        "pending_balance": to_xmr(amt_due),
        "paid_total": to_xmr(amt_paid),
        "last_payout_ts": data.get("lastPayment") or None,
        "latency_ms": round(latency_ms, 1),
        # blocks_mined intentionally left at the empty default: MoneroOcean's
        # profit-switching, multi-algo model has no per-wallet "blocks found"
        # concept exposed via its API, unlike 2Miners/HeroMiners.
        "raw": data,
        "error": None,
    })
    return stats


# ── HeroMiners (ALPH) ────────────────────────────────────────────────────
# Confirmed shape via live fetch: https://<coin>.herominers.com/api/stats_address?address=<wallet>
async def fetch_herominers_stats(coin_subdomain: str, wallet: str) -> dict:
    pool_name = "HeroMiners"
    if not wallet:
        return _empty_pool_stats(pool_name, "No wallet configured")
    url = f"https://{coin_subdomain}.herominers.com/api/stats_address"
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            resp, latency_ms = await _timed_get(client, url, params={"address": wallet, "longpoll": "false"})
            resp.raise_for_status()
            data = resp.json()
    except httpx.RequestError as e:
        logger.warning("HeroMiners API unreachable: %s", e)
        return _empty_pool_stats(pool_name, f"Pool unreachable: {e}")
    except Exception as e:
        logger.warning("HeroMiners API error: %s", e)
        return _empty_pool_stats(pool_name, f"Pool error: {e}")

    s = data.get("stats", {}) or {}
    workers = data.get("workers", []) or []
    blocks_found_pool_addr = s.get("blocksFoundPool", 0) or 0
    network_height = s.get("networkHeight")

    pool_hashrate = s.get("hashrate", 0) or 0
    round_hashes = s.get("roundHashes", 0) or 0
    shares_good = s.get("shares_good", 0) or 0
    shares_invalid = s.get("shares_invalid", 0) or 0
    shares_stale = s.get("shares_stale", 0) or 0

    # "unlocked" is wallet-scoped (this URL was queried with OUR address) —
    # every entry is a matured block this address was credited a share of.
    unlocked_raw = data.get("unlocked") or []
    blocks_mined = []
    for u in unlocked_raw:
        if not isinstance(u, dict):
            continue
        blocks_mined.append(_normalize_block_entry(
            height=u.get("height"),
            hash_=u.get("hash"),
            reward_coin_units=float(u.get("reward", 0) or 0) / 1e9,
            timestamp=u.get("ts", u.get("timestamp")),
            percent=u.get("percent"),
            orphan=False,
        ))
    blocks_mined.sort(key=lambda b: b["height"] or 0, reverse=True)

    payments_raw = data.get("payments") or []
    payout_history = []
    for p in payments_raw:
        if not isinstance(p, dict):
            continue
        payout_history.append({
            "amount": float(p.get("amount", 0) or 0) / 1e9,
            "timestamp": p.get("ts", p.get("timestamp")),
            "tx": p.get("tx") or p.get("hash"),
        })
    payout_history.sort(key=lambda p: p["timestamp"] or 0, reverse=True)

    # Round luck: your share of the current round's hashes vs. the pool's
    # total — a direct read on how "lucky" the round has been so far for you.
    pool_round_hashes = s.get("poolRoundHashes", 0) or 0
    pool_luck_percent = round(100 * round_hashes / pool_round_hashes, 4) if pool_round_hashes else None

    stats = _empty_pool_stats(pool_name)
    stats.update({
        "reachable": True,
        "pool_hashrate": float(pool_hashrate),
        "effective_hashrate": float(pool_hashrate),
        "workers_online": len(workers),
        "worker_status": "online" if pool_hashrate and pool_hashrate > 0 else ("offline" if workers is not None else "unknown"),
        "pending_balance": 0.0,  # HeroMiners stats_address doesn't expose a pending balance field directly
        "paid_total": sum(p["amount"] for p in payout_history) if payout_history else 0.0,
        "last_payout_ts": payout_history[0]["timestamp"] if payout_history else None,
        "pool_luck_percent": pool_luck_percent,
        "latency_ms": round(latency_ms, 1),
        "blocks_found": blocks_found_pool_addr,
        "blocks_mined": blocks_mined,
        "payout_history": payout_history,
        "new_block_height": network_height,
        "raw": data,
        "error": None,
        "_shares_good": shares_good,
        "_shares_invalid": shares_invalid,
        "_shares_stale": shares_stale,
    })
    return stats


# ── 2Miners (ETC / RVN / ERG) ────────────────────────────────────────────
# Confirmed via official docs: GET https://<coin>.2miners.com/api/accounts/<wallet>
async def fetch_2miners_stats(coin_subdomain: str, wallet: str) -> dict:
    pool_name = "2Miners"
    if not wallet:
        return _empty_pool_stats(pool_name, "No wallet configured")
    url = f"https://{coin_subdomain}.2miners.com/api/accounts/{wallet}"
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            resp, latency_ms = await _timed_get(client, url)
            resp.raise_for_status()
            data = resp.json()
    except httpx.RequestError as e:
        logger.warning("2Miners API unreachable: %s", e)
        return _empty_pool_stats(pool_name, f"Pool unreachable: {e}")
    except Exception as e:
        logger.warning("2Miners API error: %s", e)
        return _empty_pool_stats(pool_name, f"Pool error: {e}")

    current_hashrate = data.get("currentHashrate", 0) or 0
    hashrate_avg = data.get("hashrate", current_hashrate) or current_hashrate
    workers = data.get("workers", {}) or {}
    workers_online = 0
    if isinstance(workers, dict):
        for w in workers.values():
            if isinstance(w, dict) and (w.get("hashrate", 0) or 0) > 0:
                workers_online += 1

    # "rewards" is wallet-scoped by construction — this URL was queried with
    # OUR wallet, so every entry here is a block this address was credited
    # for (PPLNS share of a block the pool found), newest first.
    rewards_raw = data.get("rewards") or []
    blocks_mined = []
    for r in rewards_raw:
        if not isinstance(r, dict):
            continue
        height = r.get("blockheight", r.get("height"))
        blocks_mined.append(_normalize_block_entry(
            height=height,
            hash_=r.get("hash"),
            reward_coin_units=float(r.get("reward", 0) or 0) / 1e9,
            timestamp=r.get("timestamp"),
            percent=r.get("percent"),
            orphan=r.get("orphan", False),
        ))
    blocks_mined.sort(key=lambda b: b["height"] or 0, reverse=True)

    payments_raw = data.get("payments") or []
    payout_history = []
    for p in payments_raw:
        if not isinstance(p, dict):
            continue
        payout_history.append({
            "amount": float(p.get("amount", 0) or 0) / 1e9,
            "timestamp": p.get("timestamp", p.get("ts")),
            "tx": p.get("tx") or p.get("hash"),
        })
    payout_history.sort(key=lambda p: p["timestamp"] or 0, reverse=True)

    # currentLuck comes back as a string (e.g. "98.50" or "98.50%") on the
    # 2Miners account model — strip any % and parse defensively.
    luck_raw = data.get("currentLuck")
    pool_luck_percent = None
    if luck_raw is not None:
        try:
            pool_luck_percent = float(str(luck_raw).replace("%", "").strip())
        except ValueError:
            pool_luck_percent = None

    stats = _empty_pool_stats(pool_name)
    stats.update({
        "reachable": True,
        "pool_hashrate": float(current_hashrate),
        "effective_hashrate": float(hashrate_avg),
        "workers_online": workers_online if workers else (1 if current_hashrate else 0),
        "worker_status": "online" if current_hashrate and current_hashrate > 0 else "offline",
        "pending_balance": float(data.get("stats", {}).get("balance", 0) or 0) / 1e9 if isinstance(data.get("stats"), dict) else 0.0,
        "immature_balance": float(data.get("stats", {}).get("immature", 0) or 0) / 1e9 if isinstance(data.get("stats"), dict) else 0.0,
        "paid_total": float(data.get("stats", {}).get("paid", 0) or 0) / 1e9 if isinstance(data.get("stats"), dict) else 0.0,
        "last_payout_ts": payout_history[0]["timestamp"] if payout_history else None,
        "pool_luck_percent": pool_luck_percent,
        "latency_ms": round(latency_ms, 1),
        "blocks_found": len([b for b in blocks_mined if not b["orphan"]]),
        "blocks_mined": blocks_mined,
        "payout_history": payout_history,
        "new_block_height": blocks_mined[0]["height"] if blocks_mined else None,
        "raw": data,
        "error": None,
    })
    return stats


# ── Coin -> pool dispatcher ───────────────────────────────────────────────
# Maps each coin to the pool family + subdomain needed for the API calls.
# Wallets are read out of each coin's miner config file by the caller and
# passed in here, so this module has zero hardcoded wallet addresses.
POOL_DISPATCH = {
    "XMR":  {"family": "moneroocean", "subdomain": None},
    "ALPH": {"family": "herominers",  "subdomain": "alephium"},
    "ETC":  {"family": "2miners",     "subdomain": "etc"},
    "RVN":  {"family": "2miners",     "subdomain": "rvn"},
    "ERG":  {"family": "2miners",     "subdomain": "erg"},
}


async def fetch_pool_stats(coin_key: str, wallet: str) -> dict:
    """Single entrypoint: fetch normalized pool stats for any supported coin."""
    entry = POOL_DISPATCH.get(coin_key)
    if not entry:
        return _empty_pool_stats("unknown", f"No pool mapping for coin {coin_key}")

    family = entry["family"]
    try:
        if family == "moneroocean":
            return await fetch_moneroocean_stats(wallet)
        elif family == "herominers":
            return await fetch_herominers_stats(entry["subdomain"], wallet)
        elif family == "2miners":
            return await fetch_2miners_stats(entry["subdomain"], wallet)
    except Exception as e:
        logger.exception("Unexpected error fetching pool stats for %s", coin_key)
        return _empty_pool_stats(family, f"Unexpected error: {e}")

    return _empty_pool_stats(family, "Unhandled pool family")
