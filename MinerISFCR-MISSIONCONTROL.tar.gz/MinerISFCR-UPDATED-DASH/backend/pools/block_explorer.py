"""
Blockscout enrichment — adds richer on-chain detail (full hash, tx count,
gas used, exact timestamp) to a block height that 2Miners already told us
about. Only wired up for ETC: Blockscout is an EVM-chain explorer, and ETC
is the only EVM-compatible coin in this project (RVN, ERG, ALPH and XMR
each have their own non-EVM chains with no Blockscout instance).

Uses the official public instance at https://etc.blockscout.com — no API
key required for the REST v2 API. A block's on-chain data is immutable
once mined, so results are cached in memory forever (capped) rather than
re-fetched on every poll.
"""
import logging
import httpx

logger = logging.getLogger("isfcr-mining-console.blockscout")

HTTP_TIMEOUT = 8.0
ETC_BLOCKSCOUT_BASE = "https://etc.blockscout.com/api/v2"

_cache: dict[int, dict] = {}
_CACHE_MAX_ENTRIES = 500


def supports_enrichment(coin_key: str) -> bool:
    return coin_key == "ETC"


async def enrich_etc_block(height: int) -> dict | None:
    if height in _cache:
        return _cache[height]

    url = f"{ETC_BLOCKSCOUT_BASE}/blocks/{height}"
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            data = resp.json()
    except httpx.RequestError as e:
        logger.warning("Blockscout unreachable for ETC block %s: %s", height, e)
        return None
    except Exception as e:
        logger.warning("Blockscout error for ETC block %s: %s", height, e)
        return None

    miner = data.get("miner") or {}
    enriched = {
        "height": height,
        "hash": data.get("hash"),
        "timestamp": data.get("timestamp"),
        "tx_count": data.get("transaction_count") or data.get("transactions_count"),
        "gas_used": data.get("gas_used"),
        "gas_limit": data.get("gas_limit"),
        "miner_address": miner.get("hash") if isinstance(miner, dict) else None,
        "difficulty": data.get("difficulty"),
        "size_bytes": data.get("size"),
        "explorer_url": f"https://etc.blockscout.com/block/{height}",
    }

    if len(_cache) >= _CACHE_MAX_ENTRIES:
        _cache.pop(next(iter(_cache)))  # drop oldest-inserted entry
    _cache[height] = enriched
    return enriched
